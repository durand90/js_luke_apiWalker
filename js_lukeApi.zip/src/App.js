import React, { useState } from 'react';
import './App.css';

//import Fetch from './components/Fetch';
import Input from './components/Input';
import People from './components/People';
import Planets from './components/Planets';

import { BrowserRouter, Switch, Link, Route } from 'react-router-dom';





function App() {

    const [string, setString] = useState(0);

    const work = (news) => {
      setString(news);
      console.log(news)
    }


  return (
    <BrowserRouter>
      <Input work={work}/>
      <hr />
      <Switch>
        <Route path="/people/:id">
          <People space={string}/>
        </Route>
        <Route path="/planets/:id">
          <Planets/>
        </Route>
        <hr/>
      <p>{JSON.stringify(string)}</p>
      </Switch>
    </BrowserRouter>
    
  );
}

export default App;
