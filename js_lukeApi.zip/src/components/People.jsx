import React from 'react';
import { useEffect, useState } from 'react';

import { useParams } from 'react-router';



import axios from 'axios';

const People = (props) => {



    const [user, setUser] = useState({});
    const { id } = useParams();

    //const { string } = useParams();
    const [error, setError] = useState(false);

    useEffect(() => {
        axios.get(`https://swapi.dev/api/people/${id}`)
            .then(response => {
                console.log(response.data)
                setUser(response.data)
                setError(false)
            })
            .catch(response => {
                console.log("^^^^^^^^^^^^^")
                console.log(response)
                setError(true)
            })
        //console.log(num)
        //console.log()
    }, [id])

    if (error === false) {


        return (
            <div>
                <h1>more</h1>
                {<h1>{user.name}</h1>}
                {<p>Height: {user.height}</p>}
                {<p>Mass: {user.mass}</p>}
                {<p>Hair Color: {user.hair_color}</p>}
                {<p>skin Color: {user.skin_color}</p>}
                {JSON.stringify(props.space)}
                {console.log(id)}
            </div>
        );
    }
    else {
        return (
        <div>
            <h1>These aren't the droids you are looking for!!!!!!!!!!</h1>
            <img src='https://upload.wikimedia.org/wikipedia/en/3/32/Ben_Kenobi.png'/>
        </div>
        );
    }

}

export default People;