import React, { useState, useParams } from 'react';

import { useHistory } from 'react-router';

const Input = (props) => {


    const subjects = [
        "people",
        "planets",
        "films",
        "species",
        "vehicles",
        "starships"
    ]

    const [allSubjects, setAllSubjects] = useState(subjects[0]);
    const [cat, setCat] = useState("")
    const [id, setId] = useState(0)
    const history = useHistory();

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("submitted")
        props.work(id);
        history.push("/" + allSubjects + "/" + id)
        console.log(history)
    }


    return (
        <div>
            <form onSubmit={handleSubmit}>
                {JSON.stringify(subjects)}
                {JSON.stringify(id)}
                <h1>hello</h1>
                <div style={{ display: "inline" }}>
                    <div>
                    <p>Search for: </p>
                    <select value={allSubjects} onChange={e => setAllSubjects(e.target.value)}>
                        {subjects.map((subject, index) =>
                            <option key={index} value={subject}>{subject}</option>
                        )}
                    </select>
                    </div>
                    <p>ID:</p>
                    <input onChange={(e) => {setId(e.target.value)}}type="text" value={id}/>
                    {console.log(subjects)}
                </div>
                <div>
                    <button>Search</button>
                </div>
            </form>
        </div>
    );
}

export default Input;